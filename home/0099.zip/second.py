def sayMyName():
    print("김민상 더하기")


def addNumbers(*args):
    result = 0
    for val in args:
        result += val

    return result


def mulNumbers(*args):
    result = 1
    for val in args:
        result *= val

    return result