
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from selenium import webdriver

def seles(url):
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36")

    path = "C:/chrome/chromedriver.exe"
    driver = webdriver.Chrome(path)
    driver.get(url)
