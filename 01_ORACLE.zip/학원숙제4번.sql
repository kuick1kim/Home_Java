@F:\01_ORACLE\sql_practice\create_table.sql;





@F:\01_ORACLE\sql_practice\1.address.sql;


@F:\01_ORACLE\sql_practice\2.customer.sql;

@F:\01_ORACLE\sql_practice\3.item.sql;
@F:\01_ORACLE\sql_practice\4.reservation.sql;
@F:\01_ORACLE\sql_practice\5.order_info.sql;


select *
from T_shopping_goods;

--@F:\01_ORACLE\sql_practice\delete_table.sql;

select count(*) 전체주문건,
    SUM(B.sales) 총매출,
    avg(B.sales) 평균매출,
    max(B.sales) 최고매출,
    min(B.sales) 최저매출
from reservation A, order_info B
where A.reserv_no = B.reserv_no;


select count(*) 총판매량,
    sum(B.sales) 총매출,
    sum(decode(B.item_id, 'M0001', 1,0)) 전용 상품 판매량,
    sum(decode(B.item_id, 'M0001', B.sales, 0)) 전용 상품 매출
from reservation A, order_info B
where A.reserv_no = B.reserv_no
and A.cancel = 'N';
    

select count(*) 총판매량,
    sum(B.sales) 총매출,
    sum(DECODE(B.item_id,'M0001',1,0)) 전용상품판매량,
    SUM(DECODE(B.item_id,'M0001',B.sales,0)) 전용상품매출
FROM reservation A, order_info B
WHERE A.reserv_no = B.reserv_no
AND   A.cancel    = 'N';


SELECT
    *
FROM reservation;


SELECT C.item_id 상품아이디,
    C.product_name 상품이름,
    SUM(B.sales) 상품매출
FROM reservation A, order_info B, item C
where A.reserv_no =B.reserv_no
and B.item_id = C.item_id
and A.cancel ='N'
group by c.item_id, c.product_name
order by sum(b.sales) desc;



SELECT SUBSTR(A.reserv_date,1,6) 매출월,  
    sum(decode(b.item_id, 'M0001', b.sales, 0)) special_set,
    sum(decode(b.item_id, 'M0002', b.sales, 0)) pasta,
    sum(decode(b.item_id, 'M0003', b.sales, 0)) pizza,
    sum(decode(b.item_id, 'M0004', b.sales, 0)) sea_food,
    sum(decode(b.item_id, 'M0005', b.sales, 0)) steak,
    sum(decode(b.item_id, 'M0006', b.sales, 0)) salad_bar,
    sum(decode(b.item_id, 'M0007', b.sales, 0)) salad,
    sum(decode(b.item_id, 'M0008', b.sales, 0)) sandwich,
    sum(decode(b.item_id, 'M0009', b.sales, 0)) wine,
    sum(decode(b.item_id, 'M0010', b.sales, 0)) juice
from reservation A, order_info B
where A.reserv_no = B.reserv_no
and A.cancel ='N'
Group by substr(a.reserv_date, 1,6)
order by substr(a.reserv_date,1,6);





select substr(a.reserv_date, 1,6) 매출월,
    sum(b.sales) 총매출,
    sum(decode(b.item_id, 'M0001', B.sales, 0)) 전용상품매출
from reservation A, order_info B
where a.reserv_no = b.reserv_no
and a.cancel ='N'
group by substr(a.reserv_date, 1,6)
order by substr(a.reserv_date, 1,6);


select substr(a.reserv_date, 1,6) 매출월,
    sum(b.sales)
    -sum(decode(b.item_id, 'M0001', b.sales, 0)) 전용상품외에매출,
    sum(decode(b.item_id, 'M0001', b.sales,0)) 전용상품매출,
    round(sum(decode(b.item_id, 'M0001', b.sales, 0))/sum(b.sales)*100,1) 매출기여울
from reservation a, order_info b
where a.reserv_no = b.reserv_no
and a.cancel ='N'
group by substr(a.reserv_date, 1,6)
order by substr(a.reserv_date, 1,6);



SELECT SUBSTR(a.reserv_date,1,6) 매출월, 
       SUM(B.sales) 총매출,       
       SUM(B.sales) 
       - SUM(decode(B.item_id,'M0001',B.sales,0)) 전용상품외매출, 
       SUM(DECODE(B.item_id,'M0001',B.sales,0)) 전용상품매출,
       ROUND(SUM(DECODE(B.item_id,'M0001',B.sales,0))/SUM(B.sales)*100,1)||'%' 매출기여율,
       count(a.reserv_no) 총예약건,
       sum(decode(a.cancel, 'N', 1, 0)) 예약완료건,
       sum(decode(a.cancel, 'Y', 1, 0)) 예약취소건
FROM reservation A, order_info B
WHERE A.reserv_no = B.reserv_no(+)
-- AND   A.cancel    = 'N'
GROUP BY SUBSTR(A.reserv_date,1,6)
ORDER BY SUBSTR(A.reserv_date,1,6);




SELECT SUBSTR(A.reserv_date,1,6) 매출월, 
       SUM(B.sales) 총매출, 
       SUM(B.sales) 
       - SUM(decode(B.item_id,'M0001',B.sales,0)) 전용상품외매출, 
       SUM(DECODE(B.item_id,'M0001',B.sales,0)) 전용상품매출,
       ROUND(SUM(DECODE(B.item_id,'M0001',B.sales,0))/SUM(B.sales)*100,1) 매출기여율,
       COUNT(A.reserv_no) 총예약건,
       SUM(DECODE(A.cancel,'N',1,0)) 예약완료건,
       SUM(DECODE(A.cancel,'Y',1,0)) 예약취소건
FROM reservation A, order_info B
WHERE A.reserv_no = B.reserv_no
-- AND   A.cancel    = 'N'
GROUP BY SUBSTR(A.reserv_date,1,6)
ORDER BY SUBSTR(A.reserv_date,1,6);





select substr(reserv_date,1,6) 날짜,
    a.product_name 상품명,
    sum(decode(a.week, '1', a.sales, 0)) 일요일,
    sum(decode(a.week, '2', a.sales, 0)) 월요일,
    sum(decode(a.week, '3', a.sales, 0)) 화요일,
    sum(decode(a.week, '4', a.sales, 0)) 수요일,
    sum(decode(a.week, '5', a.sales, 0)) 목요일,
    sum(decode(a.week, '6', a.sales, 0)) 금요일,
    sum(decode(a.week, '7', a.sales, 0)) 토요일
from
    (
   select a.reserv_date,
    c.product_name,
    to_char(to_date(a.reserv_date, 'YYYYMMDD'),'d') week,
    b.sales
    from reservation a, order_info b, item c
    where a.reserv_no = b.reserv_no
    and b.item_id = c.item_id
    and b.item_id = 'M0001' 
    ) a
group by substr(reserv_date, 1,6), a.product_name
order by substr(reserv_date, 1,6);



\\\


;

select *
from
    (
    select substr(a.reserv_date, 1,6) 매출월,
    A.branch                 지점,
    SUM(B.sales)              전용상품매출,
    rank() over(partition by substr(a.reserv_date, 1,6)
    order by sum (b.sales) desc) 지점순위
    from reservation a, order_info b
    where a.reserv_no = b.reserv_no
    and a.cancel ='N'
    and b.item_id = 'M0001'
    group by substr(a.reserv_date,1,6), a.branch
    order by substr(a.reserv_date,1,6)
    )A
    where a.지점순위 <= 3;
    
    
    
    
select *
from
    (
    select substr(a.reserv_date, 1,6) 매출월,
    A.branch                 지점,
    SUM(B.sales)              전용상품매출,
    row_number() over(partition by substr(a.reserv_date, 1,6)
    order by sum (b.sales) desc) 지점순위,
    decode(a.branch, '강남', 'A', '종로', 'A', '영등포', 'A', 'B') 지점등급
    from reservation a, order_info b
    where a.reserv_no = b.reserv_no
    and a.cancel ='N'
    and b.item_id = 'M0001'
    group by substr(a.reserv_date,1,6), a.branch
    order by substr(a.reserv_date,1,6)
    )A
    where a.지점순위 <= 1;
    
    
    
    
SELECT A.매출월                매출월,
       MAX(총매출)             총매출,
       MAX(전용상품외매출)     전용상품외매출,
       MAX(전용상품매출)       전용상품매출,
       MAX(전용상품판매율)     전용상품판매율,
       MAX(총예약건)           총예약건,
       MAX(예약완료건)         예약완료건,
       MAX(예약취소건)         예약취소건,
       MAX(예약취소율)         예약취소율,
       MAX(최대매출지점)       최대매출지점,
       MAX(지점매출액)         지점매출액
from
(
    select substr(a.reserv_date,1,6) 매출월,
        sum(b.sales) 총매출,
        sum(b.sales)
        - sum(decode(b.item_id, 'M0001', b.sales, 0)) 전용상품외매출,
        sum(decode(b.item_id, 'M0001', b.sales, 0)) 전용상품매출,
        round(sum(decode(b.item_id, 'M0001', b.sales,0 ))/sum(b.sales)*100,
        1)||'%' 전용상품판매율,
            count(a.reserv_no) 총예약건,
            sum(Decode(a.cancel,'N', 1,0))예약완료건,
            sum(decode(a.cancel, 'Y', 1,0)) 예약취소건,
            round(sum(decode(a.cancel, 'Y',1,0))/count(a.reserv_no)*100,1)||'%' 예약취소율,
            '' 최대매출지점,
            0 지점매출액
            from reservation a, order_info B
            where a.reserv_no = b.reserv_no(+)
            --and a.cancel = 'N'
            group by substr(a.reserv_date,1,6), '',0
            union
                select a.매출월,
                    0   총매출,
                    0   전용상품외의매출,
                    0   전용상품매출,
                    ''  전용상품판매율,
                    0   총예약건,
                    0   예약완료건,
                    0   예약취소건,
                    ''  예약취소율,
                    a.지점    최대매출지점,
                    a.전용상품매출    지점매출액
                    
            from
            (
            select substr(a.reserv_date, 1,6) 매출월, 
            a.branch    지점
            sum(b.sales)    전용상품매출,
            row_number() over(partition by substr(a.reserv_date,1,6))
            order by sum(b.sales) desc  ) 지점순위,
            decode(a.branch, '강남', 'A', '종로', 'A', '영등포', 'A', 'B') 지점등급
            from reservation a,order_info b
            where a.reserv_no = b.reserv_no
            and a.cancel ='N'
            and b.item_id = 'M0001'
            GROUP BY SUBSTR(A.reserv_date,1,6), A.branch, 
            DECODE(A.branch,'강남','A','종로','A','영등포','A','B')
            ORDER BY SUBSTR(A.reserv_date,1,6)
            ) A
            WHERE A.지점순위 = 1 
             -- AND 지점등급 = 'A'
            ) A
            
            group by a.매출월
            order by a.매출월;
            
            
            
            
            

