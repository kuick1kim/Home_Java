import pymysql
from flask import Flask, render_template, request

sensor_db = pymysql.connect(
    user='root1', 
    passwd='1111', 
    host='127.0.0.1', 
    db='connectdb', 
    charset='utf8'
)

# mysql전체보기
cursor = sensor_db.cursor(pymysql.cursors.DictCursor)
sql = "SELECT * FROM professor;"
cursor.execute(sql)

result = cursor.fetchall()

# class Database():
#     def __init__(self):
#         self.db = pymysql.connect(
#                                 user='root1', 
#                                 passwd='1111', 
#                                 host='127.0.0.1', 
#                                 db='connectdb', 
#                                 charset='utf8'
#                             )
#         self.cursor= self.db.cursor(pymysql.cursors.DictCursor)
 
#     def execute(self, query, args={}):
#         self.cursor.execute(query, args) 
 
#     def executeOne(self, query, args={}):
#         self.cursor.execute(query, args)
#         row= self.cursor.fetchone()
#         return row
 
#     def executeAll(self, query, args={}):
#         self.cursor.execute(query, args)
#         row= self.cursor.fetchall()
#         return row
 
#     def commit(self):
#         self.db.commit()


#Flask 객체 인스턴스 생성
app = Flask(__name__)


@app.route('/') # 접속하는 url
def index():    
    sensor_db = pymysql.connect(
    user='root1', 
    passwd='1111', 
    host='127.0.0.1', 
    db='connectdb', 
    charset='utf8'
    )
 
        
    cursor = sensor_db.cursor(pymysql.cursors.DictCursor)
    sql = "SELECT * FROM professor;"
    cursor.execute(sql)
    result = cursor.fetchall()        
    return render_template('index2.html',data_list1=result)

# SELECT 함수 예제
@app.route('/insert', methods=['GET'])
def insert():

    sql = "INSERT INTO professor (_id,name,belong,phone) VALUES('6','이','1','01029249712');"
    cursor.execute(sql)
    sql = "COMMIT;"
    cursor.execute(sql)

    sql = "SELECT * FROM professor;"
    cursor.execute(sql)
    result = cursor.fetchall()  

 
    return render_template('index2.html',data_list1=result, result='insert is done!')
                      
@app.route('/ddd', methods=['GET'])
def ddd():
  
    sql = "DELETE FROM professor WHERE _id = 6;"
    cursor.execute(sql)
    sql = "COMMIT;"
    cursor.execute(sql)
    sql = "SELECT * FROM professor;"
    cursor.execute(sql)
    result = cursor.fetchall()  

 
    return render_template('index2.html',data_list1=result, result='DELETE is done!')
                        

if __name__=="__main__":
    app.run(debug=True)
    # host 등을 직접 지정하고 싶다면
    # app.run(host="0.0.0.0", port="8080", debug=True)



