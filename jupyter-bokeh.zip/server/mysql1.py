import pymysql


sensor_db = pymysql.connect(
    user='root1', 
    passwd='1111', 
    host='127.0.0.1', 
    db='connectdb', 
    charset='utf8'
)
cursor = sensor_db.cursor(pymysql.cursors.DictCursor)
sql = "SELECT * FROM professor;"
cursor.execute(sql)

result = cursor.fetchall()
print(result)
