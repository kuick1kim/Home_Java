import pymysql
from flask import Flask, render_template, request
import dbModule
from flask import Blueprint, request, render_template, flash, redirect, url_for


sensor_db = pymysql.connect(
    user='root1', 
    passwd='1111', 
    host='127.0.0.1', 
    db='connectdb', 
    charset='utf8'
)



# # mysql전체보기
# cursor = sensor_db.cursor(pymysql.cursors.DictCursor)
# sql = "SELECT * FROM professor;"
# cursor.execute(sql)
# result = cursor.fetchall()


app= Blueprint('test', __name__, url_prefix='/test')


@app.route('/', methods=['GET'])
def index():
    return render_template('test.html',
                            result=None,
                            resultData=None,
                            resultUPDATE=None)



@app.route('/insert', methods=['GET'])
def insert():
    db_class= dbModule.Database()
 
    sql     = "INSERT INTO testDB.testTable(test) \
                VALUES('%s')"% ('testData')
    db_class.execute(sql)
    db_class.commit()
 
    return render_template('test.html',
                           result='insert is done!',
                           resultData=None,
                           resultUPDATE=None)



# SELECT 함수 예제
@app.route('/select', methods=['GET'])
def select():
    db_class= dbModule.Database()
 
    sql     = "SELECT idx, test \
                FROM testDB.testTable"
    row     = db_class.executeAll(sql)
 
    print(row)
 
    return render_template('test.html',
                            result=None,
                            resultData=row[0],
                            resultUPDATE=None)
 


# app = Flask(__name__)

# @app.route('/') # 접속하는 url
# def index():      
#     cursor = sensor_db.cursor(pymysql.cursors.DictCursor)
#     sql = "SELECT * FROM professor;"
#     cursor.execute(sql)
#     result = cursor.fetchall()        
#     return render_template('index2.html',data_list1=result)
    
if __name__=="__main__":
    app.run(debug=True)
    # host 등을 직접 지정하고 싶다면
    # app.run(host="0.0.0.0", port="8080", debug=True)

